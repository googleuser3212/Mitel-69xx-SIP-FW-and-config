<?php
#############################################################################
# Contact lookup
# Mitel SIP Phones R1.4.2 or better
#
# php source code
# Copyright Mitel Networks 2005-2015
#
# Supported Aastra Phones
#    All Phones but 9112i, 9133i
#
# contacts.php?source=SOURCE&user=USER
# where
#    SOURCE 	is the name of the csv file to use (SOURCE.txt), if not provided
#		the default file configured in config/directory.conf is used
#    USER	is the username, if not provided the phone MAC address of the
#		phone is used.
#############################################################################

#############################################################################
# PHP customization for includes and warnings
#############################################################################
$os = strtolower(PHP_OS);
if(strpos($os, 'win') === false) ini_set('include_path',ini_get('include_path').':include:../include');
else ini_set('include_path',ini_get('include_path').';include;..\include');
error_reporting(E_ERROR | E_PARSE);

#############################################################################
# Includes
#############################################################################
require_once('AastraIPPhoneTextMenu.class.php');
require_once('AastraIPPhoneTextScreen.class.php');
require_once('AastraIPPhoneInputScreen.class.php');
require_once('AastraIPPhoneExecute.class.php');
require_once('AastraCommon.php');

#############################################################################
# Private functions
#############################################################################

function get_user_config($user)
{
$array_user=Aastra_get_user_context($user,'contacts');
if($array_user['display']=='') $array_user['display']='firstlast';
if($array_user['sort']=='') $array_user['sort']='first';
Aastra_save_user_context($user,'contacts',$array_user);
return($array_user);
}

function prepare_number($phone,$type,$conf_dir)
{
$local=$phone;

# For display purpose
if($type==1)
	{
	# Prepare name for display
	$local=preg_replace('/ /','',$local);
	}
else
	{
	# Prepare number for dialing
	if (strstr($local,'+'.$conf_dir['country'].' ')) $local=$conf_dir['long distance'].preg_replace('/\+'.$conf_dir['country'].'/','',$local);
	else $local=preg_replace('/\+/',$conf_dir['international'],$local);

	# Remove  spaces and -
	$local=preg_replace('/ /','',$local);
	$local=preg_replace('/-/','',$local);

	# Remove (0)
	$local=preg_replace('/\(0\)/','',$local);

	# Remove ( and )
	$local=preg_replace('/\(/','',$local);
	$local=preg_replace('/\)/','',$local);

	# Extract the extension
	if(strstr($local,'x'))
		{
		$explode=explode('x',$local,2);
		$local=$explode[0];
		}

	# Local number?
	$found=False;
	if($conf_dir['local']!='')
		{
		$array_local=explode(',',$conf_dir['local']);
		foreach($array_local as $key=>$value)
			{
			$search=$conf_dir['long distance'].$value;
			$replace='/'.$conf_dir['long distance'].$value.'/';
			if (strstr($local,$search)) 
				{
				$local=preg_replace($replace,'',$local);
				$found=True;
				}
			}
		}
	if(!$found) $local=$conf_dir['outgoing'].$local;
	}

# Return processed number
return($local);
}

function starts_with($haystack,$needle)
{
$pos=strpos(strtolower($haystack),strtolower($needle));
if($pos!==False)
	{
	if($pos==0) $pos=True;
	else $pos=False;
	}
return($pos);
} 

function lookup_directory($source,$lookup,$firstn,$lastn,$company,$array_user)
{
# So far so good
$return[0]=True;

# Open and read file
$handle=@fopen($source.'.txt','r');
$index=0;
$directory=array();
if($handle)
	{	
	while($line=fgets($handle,200))
		{
		$value=explode(",",trim($line,"\n"));
		if($lookup!='')
			{
			if(stristr($value[0].' '.$value[1].' '.$value[2],$lookup)) 
				{
				if(($value[4]!='') or ($value[5]!='') or ($value[6]!=''))
					{
					$directory[$index]['first']=$value[0];
					$directory[$index]['last']=$value[1];
					$directory[$index]['company']=$value[2];
					$directory[$index]['title']=$value[3];
					$directory[$index]['work']=$value[4];
					$directory[$index]['home']=$value[5];
					$directory[$index]['mobile']=$value[6];
					$index++;
					}
				}
			}
		else
			{
			if($firstn!='') $test_firstn=starts_with($value[0],$firstn);
			else $test_firstn=True;
			if($lastn!='') $test_lastn=starts_with($value[1],$lastn);
			else $test_lastn=True;
			if($company!='') $test_company=starts_with($value[2],$company);
			else $test_company=True;
			if($test_firstn and $test_lastn and $test_company) 
				{
				if(($value[4]!='') or ($value[5]!='') or ($value[6]!=''))
					{
					$directory[$index]=Array(	'first'=>$value[0],
									'last'=>$value[1],
									'company'=>$value[2],
									'title'=>$value[3],
									'work'=>$value[4],
									'home'=>$value[5],
									'mobile'=>$value[6]
								 	);
					if($company!='')
						{
						$directory2[$value[2]][]=Array(	'first'=>$value[0],
										   	'last'=>$value[1],
											'index'=>$index
											);
						}
					$index++;
					}
				}
			}
		}
	fclose($handle);
	}
else 
	{
	Aastra_debug('Cannot open contact file '.AASTRA_PATH_CACHE.$source.'.txt');
	$return[0]=False;
	}

# Sort the data
if($return[0])
	{
	switch($array_user['sort'])
		{
		case 'first':
			if($company!='')
				{
				foreach($directory2 as $key=>$value) $directory2[$key]=Aastra_array_multi_sort($value, 'first', 'asc', TRUE);
				}
			else $directory=Aastra_array_multi_sort($directory, 'first', 'asc', TRUE);
			break;
		case 'last':
			if($company!='')
				{
				foreach($directory2 as $key=>$value) $directory2[$key]=Aastra_array_multi_sort($value, 'last', 'asc', TRUE);
				}
			else $directory=Aastra_array_multi_sort($directory, 'last', 'asc', TRUE);
			break;
		}
	$return[1]=$directory;
	if($company!='') $return[2]=$directory2;
	}

# Return results
return($return);
}

#############################################################################
# Main code
#############################################################################
# Collect parameters
$header=Aastra_decode_HTTP_header();
$user=Aastra_getvar_safe('user',$header['mac']);
$action=Aastra_getvar_safe('action','input');
$source=Aastra_getvar_safe('source');
$lastn=Aastra_getvar_safe('lastn');
$firstn=Aastra_getvar_safe('firstn');
$company=Aastra_getvar_safe('company');
$lookup=Aastra_getvar_safe('lookup');
$index=Aastra_getvar_safe('index');
$page=Aastra_getvar_safe('page','1');
$speed=Aastra_getvar_safe('speed');
$input=Aastra_getvar_safe('input','lookup');

# Log call to the application
Aastra_trace_call('directory','action='.$action.', lookup='.$lookup.', page='.$page.', index='.$index.', lastn='.$lastn.', firstn='.$firstn.', user='.$user.', speed='.$speed);

# Test User Agent
Aastra_test_phone_version('1.4.2.',0);

# Test phone type
Aastra_test_phone_model(array('Aastra9112i','Aastra9133i'),False,0);

# Get Language
$language=Aastra_get_language();

# Get global compatibility
$is_multipleinputfields=Aastra_is_multipleinputfields_supported();
$is_icons=Aastra_is_icons_supported();
$is_lockin=Aastra_is_lockin_supported();
$is_style_textmenu=Aastra_is_style_textmenu_supported();
$is_formatted_textscreen=Aastra_is_formattedtextscreen_supported();
$is_textmenu_wrapitem=Aastra_is_textmenu_wrapitem_supported();
$nb_softkeys=Aastra_number_physical_softkeys_supported();
$is_toptitle_supported=Aastra_is_top_title_supported();

# Retrieve the size of the display
$chars_supported=Aastra_size_display_line();
if($is_style_textmenu) $chars_supported--;

# To handle non softkey phones
if($nb_softkeys>0) $MaxLines=AASTRA_MAXLINES;
else $MaxLines=AASTRA_MAXLINES-2;

# Load config file
$array_conf=Aastra_readINIfile(AASTRA_CONFIG_DIRECTORY.'directory.conf','#','=');
if($source=='') $source=$array_conf['General']['default'];

# Update URI
$XML_SERVER.='?user='.$user.'&source='.$source;

# Add user if password OK
if (!empty($passwd))
	{
	if($passwd==$array_conf['General']['password']) Aastra_add_access('directory');
	else
		{
		$object=new AastraIPPhoneTextScreen();
		$object->setDestroyOnExit();
		$object->setTitle(Aastra_get_label('Access Denied',$language));
		$object->setText(Aastra_get_label('Wrong password.',$language));
		$object->output();
		exit;
		}
	}

# If needed test if user is authorized
if($array_conf['General']['password']!='') Aastra_test_access('directory','passwd',$XML_SERVER);

# Get user context
$array_user=get_user_config($user);

# Process action
switch($action)
	{
	# Settings
	case 'settings':
		$object=new AastraIPPhoneTextMenu();
		$object->setDestroyOnExit();
		$object->setTitle(Aastra_get_label('Settings',$language));
		if($is_style_textmenu) $object->setStyle('none');
		if($index!='') $object->setDefaultIndex($index);
		$text=array(	'firstlast'=>Aastra_get_label('First Last',$language),
				'lastfirst'=>Aastra_get_label('Last First',$language)
				);
		$object->addEntry(sprintf(Aastra_get_label('Display: %s',$language),$text[$array_user['display']]),$XML_SERVER.'&action=set_display','');
		$text=array(	'last'=>Aastra_get_label('Last Name',$language),
				'first'=>Aastra_get_label('First Name',$language)
				);
		$object->addEntry(sprintf(Aastra_get_label('Sort: %s',$language),$text[$array_user['sort']]),$XML_SERVER.'&action=set_sort','');
		if($nb_softkeys>0)
			{
			if($nb_softkeys==6)
				{
				$object->addSoftkey('1',Aastra_get_label('Change',$language),'SoftKey:Select');
				$object->addSoftkey('4',Aastra_get_label('Back',$language),$XML_SERVER.'&action=input');
				$object->addSoftkey('6',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				}
			else
				{
				$object->addSoftkey('9',Aastra_get_label('Back',$language),$XML_SERVER.'&action=input&input='.$input);
				$object->addSoftkey('10',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				$object->setCancelAction($XML_SERVER.'&action=input&input='.$input);
				}
			}
		else 
			{
			$object->addEntry(Aastra_get_label('Back',$language),$XML_SERVER.'&action=input');
			$object->setCancelAction($XML_SERVER.'&action=input');
			}
		break;

	# Change display value
	case 'set_display':
		# Save value
		if($array_user['display']=='firstlast') $array_user['display']='lastfirst';
		else $array_user['display']='firstlast';
		Aastra_save_user_context($user,'contacts',$array_user);

		# Call back
		$object=new AastraIPPhoneExecute();
		$object->addEntry($XML_SERVER.'&action=settings&index=1');
		break;

	# Change sort value
	case 'set_sort':
		# Save value
		if($array_user['sort']=='first') $array_user['sort']='last';
		else $array_user['sort']='first';
		Aastra_save_user_context($user,'contacts',$array_user);

		# Call back
		$object=new AastraIPPhoneExecute();
		$object->addEntry($XML_SERVER.'&action=settings&index=2');
		break;

	# Initial input
	case 'input':
		# Softkeys
		if($nb_softkeys>0)
			{
			# Input screen
			$object = new AastraIPPhoneInputScreen();
	   	if($is_toptitle_supported) $object->setTopTitle(Aastra_get_label('Contact Lookup',$language));
			else $object->setTitle(Aastra_get_label('Contact Lookup',$language));
      $object->setURL($XML_SERVER.'&action=lookup&input='.$input);
      $object->setDestroyOnExit();

			# Multiple fields
			if($is_multipleinputfields)
				{
       	$object->setDisplayMode('condensed');
				if(!empty($lookup)) 
					{
					$firstn='';
					$lastn='';
					$company='';
					$object->setDefaultIndex('4');
					}
				else
					{
					if (!empty($company)) $object->setDefaultIndex('1');
					if (!empty($lastn)) $object->setDefaultIndex('2');
					if (!empty($firstn))$object->setDefaultIndex('3');
					}
				$object->addField('string');
       	$object->setFieldPrompt(Aastra_get_label('Company:',$language));
        $object->setFieldParameter('company');
				if (!empty($company)) $object->setFieldDefault($company);
        $object->addField('string');
   			$object->setFieldPrompt(Aastra_get_label('Last Name:',$language));
        $object->setFieldParameter('lastn');
				if (!empty($lastn)) $object->setFieldDefault($lastn);
       	$object->addField('string');
       	$object->setFieldPrompt(Aastra_get_label('First Name:',$language));
        $object->setFieldParameter('firstn');
				if (!empty($firstn)) $object->setFieldDefault($firstn);
        $object->addField('string');
   			$object->setFieldPrompt(Aastra_get_label('Or Anywhere:',$language));
        $object->setFieldParameter('lookup');
				if (!empty($lookup)) $object->setFieldDefault($lookup);
				}
			else
				{
				# Standard phone
				if($nb_softkeys==6)
					{
					# Single input
					$object->setType('string');
					$object->setPrompt(Aastra_get_label('Letters name/company',$language));
					$object->setParameter('lookup');
					if (!empty($lookup)) $object->setDefault($lookup);
					}
				else
					{
					# Multiple choices
					$object->setType('string');
					switch($input)
						{
						case 'lookup':
							$object->setPrompt(Aastra_get_label('Letters in name/company',$language));
							$object->setParameter('lookup');
							if (!empty($lookup)) $object->setDefault($lookup);
							break;
						case 'lastn':
							$object->setPrompt(Aastra_get_label('Last Name starts with',$language));
							$object->setParameter('lastn');
							if (!empty($lastn)) $object->setDefault($lastn);
							break;
						case 'firstn':
							$object->setPrompt(Aastra_get_label('First Name starts with',$language));
							$object->setParameter('firstn');
							if (!empty($firstn)) $object->setDefault($firstn);
							break;
						case 'company':
							$object->setPrompt(Aastra_get_label('Company Name starts with',$language));
							$object->setParameter('company');
							if (!empty($company)) $object->setDefault($company);
							break;
						}
					}
				}
			
			# Softkeys
			if($nb_softkeys==4)
				{
     		$object->addSoftkey('1',Aastra_get_label('Backspace',$language),'SoftKey:BackSpace');
				$object->addSoftkey('2',Aastra_get_label('ABC',$language),'SoftKey:ChangeMode');
				$object->addSoftkey('3',Aastra_get_label('Lookup',$language),'SoftKey:Submit');
				$object->addSoftkey('4',Aastra_get_label('Settings',$language),$XML_SERVER.'&action=settings');
				$object->addSoftkey('5',Aastra_get_label('Reset',$language),$XML_SERVER.'&action=input');
				$object->addSoftkey('6',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				}
			else if($nb_softkeys==6)
				{
     		$object->addSoftkey('1',Aastra_get_label('Backspace',$language),'SoftKey:BackSpace');
				$object->addSoftkey('2',Aastra_get_label('Reset',$language),$XML_SERVER.'&action=input');
				$object->addSoftkey('3',Aastra_get_label('ABC',$language),'SoftKey:ChangeMode');
				$object->addSoftkey('4',Aastra_get_label('Settings',$language),$XML_SERVER.'&action=settings');
				$object->addSoftkey('5',Aastra_get_label('Lookup',$language),'SoftKey:Submit');
				$object->addSoftkey('6',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				}
			else
				{
				$object->addSoftkey('1',Aastra_get_label('Search anywhere',$language),$XML_SERVER.'&action=input&input=lookup');
				$object->addSoftkey('2',Aastra_get_label('Search by Last Name',$language),$XML_SERVER.'&action=input&input=lastn');
				$object->addSoftkey('3',Aastra_get_label('Search by First Name',$language),$XML_SERVER.'&action=input&input=firstn');
				$object->addSoftkey('4',Aastra_get_label('Search by Company',$language),$XML_SERVER.'&action=input&input=company');
				$object->addSoftkey('6',Aastra_get_label('Settings',$language),$XML_SERVER.'&action=settings&input='.$input);
				$object->addSoftkey('10',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				}
			}
		else
			{
			# Textmenu
			$object=new AastraIPPhoneTextMenu();
			$object->setDestroyOnExit();
			$object->setTitle(Aastra_get_label('Contact Lookup',$language));
			$object->setStyle('none');
			$object->addEntry(Aastra_get_label('Lookup',$language),$XML_SERVER.'&action=input_any');
			$object->addEntry(Aastra_get_label('Settings',$language),$XML_SERVER.'&action=settings');
			}
		break;

	# Input single
	case 'input_any':
		# Input screen
		$object = new AastraIPPhoneInputScreen();
   	$object->setTitle(Aastra_get_label('Contact Lookup',$language));
 		$object->setURL($XML_SERVER.'&action=lookup');
   	$object->setDestroyOnExit();
		$object->setType('string');
		$object->setPrompt(Aastra_get_label('Letters name/company',$language));
		$object->setParameter('lookup');
		if($lookup!='') $object->setDefault($lookup);
		break;
	
	# Lookup
	case 'lookup':
		# Make the search
		$return=lookup_directory($source,$lookup,$firstn,$lastn,$company,$array_user);

		# Search OK
		if($return[0])
			{
			# At least one result
			if(count($return[1])>0)
				{
				# Save results
				$array_directory=array('directory' => base64_encode(serialize($return)));
				Aastra_save_session('directory','600',$array_directory);

				# Call back with browse
				$object=new AastraIPPhoneExecute();
				$object->addEntry($XML_SERVER.'&action=browse&page=1&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&company='.$company.'&input='.$input);
				}
			else
				{
				# Display error
				$object=new AastraIPPhoneTextScreen();
				$object->setDestroyOnExit();
				if($is_toptitle_supported) $object->setTopTitle(Aastra_get_label('Directory Lookup',$language),'red');
				else $object->setTitle(Aastra_get_label('Directory Lookup',$language));
				$object->setText(Aastra_get_label('Sorry no match found.',$language));
				if($nb_softkeys>0)
					{
  				$object->addSoftkey($nb_softkeys-1,Aastra_get_label('Back',$language),$XML_SERVER.'&action=input&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&company='.$company);
					$object->addSoftkey($nb_softkeys,Aastra_get_label('Exit',$language),'SoftKey:Exit');
					}
				$object->setCancelAction($XML_SERVER.'&action=input&input='.$input.'&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&company='.$company);
				}
			}
		else
			{
			# Display error
			$object=new AastraIPPhoneTextScreen();
			$object->setDestroyOnExit();
			if($is_toptitle_supported) $object->setTopTitle(Aastra_get_label('Contact Lookup',$language),'red');
			else $object->setTitle(Aastra_get_label('Contact Lookup',$language));
			$object->setText(Aastra_get_label('Cannot access Contact database. Please contact your administrator.',$language));
			if($nb_softkeys>0) $object->addSoftkey($nb_softkeys,Aastra_get_label('Exit',$language),'SoftKey:Exit');
			}
		break;

	# Browse results
	case 'browse':
		# Retrieve session
		$array=Aastra_read_session('directory');
		$temp=unserialize(base64_decode($array['directory']));

		# Update global variable
		$XML_SERVER.='&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&company='.$company;

		# Group by company?
		if($company=='')
			{
			# Retrieve answer
			$directory=$temp[1];

			# How many pages
			$count=count($directory);
			$last=intval($count/$MaxLines);
			if(($count-$page*$MaxLines) != 0) $last++;

			# Create TextMenu
			$object=new AastraIPPhoneTextMenu();
			$object->setDestroyOnExit();
			$object->setStyle('none');
			if($is_toptitle_supported)
				{
				if($last!=1) $object->setTopTitle(sprintf(Aastra_get_label('Results (%s/%s)',$language),$page,$last));
				else $object->setTopTitle(Aastra_get_label('Results',$language));
				}
			else
				{
				if($last!=1) $object->setTitle(sprintf(Aastra_get_label('Results (%s/%s)',$language),$page,$last));
				else $object->setTitle(Aastra_get_label('Results',$language));
				}
			$object->setDefaultIndex(($index-(($page-1)*$MaxLines)+1));
			if($is_textmenu_wrapitem) $object->setWrapList();

			# Previous Page for non-softkey phones
			if(($nb_softkeys==0) and ($page!=1)) $object->addEntry(Aastra_get_label('Previous Page',$language),$XML_SERVER.'&page='.($page-1).'&action=browse');

			# Display list
			$object->setBase($XML_SERVER.'&action=zoom&input='.$input);
			for($index=($page-1)*$MaxLines;($index<($page*$MaxLines)) and ($index<$count);$index++)
				{
				if($array_user['display']=='firstlast') $name=$directory[$index]['first'].' '.$directory[$index]['last'];
				else $name=$directory[$index]['last'].' '.$directory[$index]['first'];
				if($is_textmenu_wrapitem) 
					{
					if($nb_softkeys==6)
						{
						$name=substr($name,0,($chars_supported-3));
						$display=str_pad($name,$chars_supported,'-',STR_PAD_BOTH);
						if($directory[$index]['company']) $display.='('.substr($directory[$index]['company'],0,($chars_supported-3)).')';
						else $display.='('.Aastra_get_label('No Company',$language).')';
						}
					else
						{
						$display=$name;
						if($directory[$index]['company']) $display.=' ('.$directory[$index]['company'].')';
						else $display.=' ('.Aastra_get_label('No Company',$language).')';
						}
					}
				else $display=$name;
				$object->addEntry($display,'&index='.$index.'&page='.$page,$index);
				}

			# Softkeys
			if($nb_softkeys>0)
				{
				if($nb_softkeys==4)
					{
					if(($page!=1) or ($page!=$last)) 
						{
						$object->addSoftkey('1', Aastra_get_label('Select',$language), 'SoftKey:Select');
						if($page!=1) $object->addSoftkey('2', Aastra_get_label('Previous',$language), $XML_SERVER.'&page='.($page-1).'&action=browse');
						if($page!=$last) $object->addSoftkey('3', Aastra_get_label('Next',$language), $XML_SERVER.'&page='.($page+1).'&action=browse');
						$object->addSoftkey('5', Aastra_get_label('Back',$language), $XML_SERVER);
						$object->addSoftkey('6', Aastra_get_label('Exit',$language), 'SoftKey:Exit');
						}
					else
						{
						$object->addSoftkey('1', Aastra_get_label('Select',$language), 'SoftKey:Select');
						$object->addSoftkey('3', Aastra_get_label('Back',$language), $XML_SERVER);
						$object->addSoftkey('4', Aastra_get_label('Exit',$language), 'SoftKey:Exit');
						}
					}
				else if($nb_softkeys==6)
					{
					$object->addSoftkey('1', Aastra_get_label('Select',$language), 'SoftKey:Select');
					if($page!=1) $object->addSoftkey('2', Aastra_get_label('Previous',$language), $XML_SERVER.'&page='.($page-1).'&action=browse');
					if($page!=$last) $object->addSoftkey('5', Aastra_get_label('Next',$language), $XML_SERVER.'&page='.($page+1).'&action=browse');
					$object->addSoftkey('4', Aastra_get_label('Back',$language), $XML_SERVER);
					$object->addSoftkey('6', Aastra_get_label('Exit',$language), 'SoftKey:Exit');
					}
				else
					{
					if($page!=1) $object->addSoftkey('3', Aastra_get_label('Previous',$language), $XML_SERVER.'&page='.($page-1).'&action=browse&input='.$input);
					if($page!=$last) $object->addSoftkey('8', Aastra_get_label('Next',$language), $XML_SERVER.'&page='.($page+1).'&action=browse&input='.$input);
					$object->addSoftkey('9', Aastra_get_label('Back',$language), $XML_SERVER.'&action=input&input='.$input);
					$object->addSoftkey('10', Aastra_get_label('Exit',$language), 'SoftKey:Exit');	
					$object->setCancelAction($XML_SERVER.'&action=input&input='.$input);
					}
				}
			else
				{
				$object->resetBase();
				if($page!=$last) $object->addEntry(Aastra_get_label('Next Page',$language),$XML_SERVER.'&page='.($page+1).'&action=browse');
				$object->setCancelAction($XML_SERVER.'&action=input_any');
				}
			}
		else
			{
			# Retrieve answer
			$directory1=$temp[1];
			$directory2=$temp[2];

			# How many pages
			$MaxLines--;
			$count=count($directory1)+count($directory2);
			$last=intval($count/$MaxLines);
			if(($count-$page*$MaxLines) != 0) $last++;

			# Create TextMenu
			$object=new AastraIPPhoneTextMenu();
			$object->setDestroyOnExit();
			$object->setStyle('none');

			# Title
			if($is_toptitle_supported)
				{
				if($last!=1) $object->setTopTitle(sprintf(Aastra_get_label('Results (%s/%s)',$language),$page,$last));
				else $object->setTopTitle(Aastra_get_label('Results',$language));
				}
			else
				{
				if($last!=1) $object->setTitle(sprintf(Aastra_get_label('Results (%s/%s)',$language),$page,$last));
				else $object->setTitle(Aastra_get_label('Results',$language));
				}

			# Default Index
			if($index=='') $object->setDefaultIndex('2');

			# Previous page for non-softkey phones			
			if(($nb_softkeys==0) and ($page!=1)) $object->addEntry('Previous Page',$XML_SERVER.'&page='.($page-1).'&action=browse');

			# Display list
			$count=0;
			$rank=1;
			$first=0;
			$object->setBase($XML_SERVER);
			foreach($directory2 as $key=>$value)
				{
				if(($count>=($page-1)*$MaxLines) and ($count<($page*$MaxLines)))
					{
					$display=substr($key,0,($chars_supported-3));
					$display=str_pad($display,$chars_supported,'-',STR_PAD_BOTH);
					if($nb_softkeys==10) $display=strtoupper($display);
					$object->addEntry($display,'');
					if($first==0) $first=1;
					$rank++;
					}
				$count++;
				foreach($value as $value2)
					{
					if(($count>=($page-1)*$MaxLines) and ($count<($page*$MaxLines)))
						{
						if($first==0)
							{
							$display=substr($key,0,($chars_supported-3));
							$display=str_pad($display,$chars_supported,'-',STR_PAD_BOTH);
							$object->addEntry($display,'&action=nothing');
							$first=1;
							$rank++;
							}
						if($array_user['display']=='firstlast') $name=$value2['first'].' '.$value2['last'];
						else $name=$value2['last'].' '.$value2['first'];
						$object->addEntry($name,'&index='.$value2['index'].'&page='.$page.'&action=zoom&input='.$input,$value2['index']);
						if(($index!='') and ($value2['index']==$index)) $object->setDefaultIndex($rank);
						$rank++;
						}
					$count++;
					}
				}

			# Softkeys
			if($nb_softkeys>0)
				{
				if($nb_softkeys==4)
					{
					if(($page!=1) or ($page!=$last)) 
						{
						$object->addSoftkey('1', Aastra_get_label('Select',$language), 'SoftKey:Select');
						if($page!=1) $object->addSoftkey('2', Aastra_get_label('Previous',$language), $XML_SERVER.'&page='.($page-1).'&action=browse');
						if($page!=$last) $object->addSoftkey('3', Aastra_get_label('Next',$language), $XML_SERVER.'&page='.($page+1).'&action=browse');
						$object->addSoftkey('5', Aastra_get_label('Back',$language), $XML_SERVER);
						$object->addSoftkey('6', Aastra_get_label('Exit',$language), 'SoftKey:Exit');
						}
					else
						{
						$object->addSoftkey('1', Aastra_get_label('Select',$language), 'SoftKey:Select');
						$object->addSoftkey('3', Aastra_get_label('Back',$language), $XML_SERVER);
						$object->addSoftkey('4', Aastra_get_label('Exit',$language), 'SoftKey:Exit');
						}
					}
				else if($nb_softkeys==6)
					{
					$object->addSoftkey('1', Aastra_get_label('Select',$language), 'SoftKey:Select');
					if($page!=1) $object->addSoftkey('2', Aastra_get_label('Previous',$language), $XML_SERVER.'&page='.($page-1).'&action=browse');
					if($page!=$last) $object->addSoftkey('5', Aastra_get_label('Next',$language), $XML_SERVER.'&page='.($page+1).'&action=browse');
					$object->addSoftkey('4', Aastra_get_label('Back',$language), $XML_SERVER);
					$object->addSoftkey('6', Aastra_get_label('Exit',$language), 'SoftKey:Exit');
					}
				else
					{
					if($page!=1) $object->addSoftkey('3', Aastra_get_label('Previous',$language), $XML_SERVER.'&page='.($page-1).'&action=browse&input='.$input);
					if($page!=$last) $object->addSoftkey('8', Aastra_get_label('Next',$language), $XML_SERVER.'&page='.($page+1).'&action=browse&input='.$input);
					$object->addSoftkey('9', Aastra_get_label('Back',$language), $XML_SERVER.'&action=input&input='.$input);
					$object->addSoftkey('10', Aastra_get_label('Exit',$language), 'SoftKey:Exit');
					$object->setCancelAction($XML_SERVER.'&action=input&input='.$input);
					}
				}
			else
				{
				if($page!=$last) $object->addEntry('Next Page','&page='.($page+1).'&action=browse');
				$object->setCancelAction($XML_SERVER.'&action=input_any');
				}
			}
		break;

	# Zoom on results
	case 'zoom':
		# Retrieve session
		$array=Aastra_read_session('directory');
		$temp=unserialize(base64_decode($array['directory']));
		$directory=$temp[1];

		# Update global variable
		$XML_SERVER.='&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&index='.$index.'&page='.$page.'&company='.$company;

		# Display details
		$object=new AastraIPPhoneTextMenu();
		$object->setDestroyOnExit();
		if($array_user['display']=='firstlast') $name=$directory[$index]['first'].' '.$directory[$index]['last'];
		else $name=$directory[$index]['last'].' '.$directory[$index]['first'];
		if($is_toptitle_supported) $object->setTopTitle($name);
		else $object->setTitle($name);
		if($is_style_textmenu) $object->setStyle('none');

		# Work number
		if($directory[$index]['work']!='')
			{
			$display=prepare_number($directory[$index]['work'],1,$array_conf['Dialplan']);
			$dial=prepare_number($directory[$index]['work'],2,$array_conf['Dialplan']);
			if($nb_softkeys==0) $dial='Dial:'.$dial;
			if($is_icons) $object->addEntry($display,$dial,'',1);
			else 
				{
				if($nb_softkeys!=10) $object->addEntry(Aastra_get_label('W',$language).' '.$display,$dial,'');
				else $object->addEntry(Aastra_get_label('W',$language).' '.$display,'','','',$dial);
				}
			}

		# Cell phone number
		if($directory[$index]['mobile']!='')
			{
			$display=prepare_number($directory[$index]['mobile'],1,$array_conf['Dialplan']);
			$dial=prepare_number($directory[$index]['mobile'],2,$array_conf['Dialplan']);
			if($nb_softkeys==0) $dial='Dial:'.$dial;
			if($is_icons) $object->addEntry($display,$dial,'',2);
			else 
				{
				if($nb_softkeys!=10) $object->addEntry(Aastra_get_label('M',$language).' '.$display,$dial,'');
				else $object->addEntry(Aastra_get_label('M',$language).' '.$display,'','','',$dial);
				}
			}

		# Home number
		if($directory[$index]['home']!='')
			{
			$display=prepare_number($directory[$index]['home'],1,$array_conf['Dialplan']);
			$dial=prepare_number($directory[$index]['home'],2,$array_conf['Dialplan']);
			if($nb_softkeys==0) $dial='Dial:'.$dial;
			if($is_icons) $object->addEntry($display,$dial,'',3);
			else 
				{
				if($nb_softkeys!=10) $object->addEntry(Aastra_get_label('H',$language).' '.$display,$dial,'');
				else $object->addEntry(Aastra_get_label('H',$language).' '.$display,'','','',$dial);
				}
			}

		# Softkeys
		if($nb_softkeys>0)
			{
			if(($nb_softkeys==4) or ($nb_softkeys==6))
				{
				$object->addSoftkey('1',Aastra_get_label('Dial',$language),'SoftKey:Dial');
				if(($directory[$index]['company']!='') or ($directory[$index]['title']!=''))$object->addSoftkey('2',Aastra_get_label('Details',$language),$XML_SERVER.'&action=details');
				if($array_conf['General']['speeddial']==1) $object->addSoftkey('3',Aastra_get_label('Speed Dial',$language),$XML_SERVER.'&action=speed');
				$object->addSoftkey('4',Aastra_get_label('Back',$language),$XML_SERVER.'&action=browse');
				$object->addSoftkey('6',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				}
			else
				{
				if(($directory[$index]['company']!='') or ($directory[$index]['title']!=''))$object->addSoftkey('1',Aastra_get_label('Details',$language),$XML_SERVER.'&action=details&input='.$input);
				if($array_conf['General']['speeddial']==1) $object->addSoftkey('6',Aastra_get_label('Add to Speed Dial',$language),$XML_SERVER.'&action=speed&input='.$input);
				$object->addSoftkey('9',Aastra_get_label('Back',$language),$XML_SERVER.'&action=browse&input='.$input);
				$object->addSoftkey('10',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				$object->setCancelAction($XML_SERVER.'&action=browse&input='.$input);
				}
			}
		else $object->setCancelAction($XML_SERVER.'&action=browse');

		# Icons
		if($is_icons)
			{
			if(!Aastra_is_graphical_display())
				{
				$object->addIcon(1,Aastra_get_custom_icon('Office'));
				$object->addIcon(2,Aastra_get_custom_icon('Cellphone'));
				$object->addIcon(3,Aastra_get_custom_icon('Home'));
				}
			else
				{
				$object->addIcon(1,'Icon:Office');
				$object->addIcon(2,'Icon:CellPhone');
				$object->addIcon(3,'Icon:Home');
				}
			}
		break;

	# Details on results
	case 'details':
		# Retrieve session
		$array=Aastra_read_session('directory');
		$temp=unserialize(base64_decode($array['directory']));
		$directory=$temp[1];

		# Update global variable
		$XML_SERVER.='&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&index='.$index.'&page='.$page.'&company='.$company;

		# Display details
		if($array_user['display']=='firstlast') $name=$directory[$index]['first'].' '.$directory[$index]['last'];
		else $name=$directory[$index]['last'].' '.$directory[$index]['first'];
		if($is_formatted_textscreen)
			{
			require_once('AastraIPPhoneFormattedTextScreen.class.php');
			$object=new AastraIPPhoneFormattedTextScreen();
			$object->setDestroyOnExit();
			if($is_toptitle_supported) $object->setTopTitle($name);
			else $object->addLine($name,'double');
			if($directory[$index]['company']!='') $object->addLine($directory[$index]['company']);
			else $object->addLine(Aastra_get_label('Company...',$language));
			if($directory[$index]['title']!='') $object->addLine($directory[$index]['title']);
			else $object->addLine(Aastra_get_label('Title...',$language));
			}
		else
			{
			$object=new AastraIPPhoneTextScreen();
			$object->setDestroyOnExit();
			$object->setTitle($name);
			if($directory[$index]['company']!='') $text=$directory[$index]['company'];
			else $text=Aastra_get_label('Company...',$language);
			if($directory[$index]['title']!='') $text.=' '.$directory[$index]['title'];
			else $text.=' '.Aastra_get_label('Title...',$language);
			$object->setText($text);
			}

		# Softkeys
		if($nb_softkeys>0)
			{
			$object->addSoftkey($nb_softkeys-1,Aastra_get_label('Back',$language),$XML_SERVER.'&action=zoom');
			$object->addSoftkey($nb_softkeys,Aastra_get_label('Exit',$language),'SoftKey:Exit');
			}
		$object->setCancelAction($XML_SERVER.'&action=zoom');
		break;


	# Speed dial
	case 'speed':
		# Update global variable
		$XML_SERVER.='&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&index='.$index.'&page='.$page.'&company='.$company;

		# Get user context
		$conf_speed=Aastra_get_user_context($user,'speed');
		$found=0;
		$i=0;
		while(($found==0) and ($i<$MaxLines))
			{
			if($conf_speed[$i]['name']=='') $found=1;
			$i++;
			}

		$object=new AastraIPPhoneTextMenu();
		$object->setDestroyOnExit();
		if($found==1) $object->setDefaultIndex($i);
		if($is_toptitle_supported) $object->setTopTitle(Aastra_get_label('Speed Dial List',$language));
		else $object->setTitle(Aastra_get_label('Speed Dial List',$language));
		for($i=0;$i<AASTRA_MAXLINES;$i++)
			{
			$name=$conf_speed[$i]['name'];
			if($name=='') $name='......................';
			$object->addEntry($name,$XML_SERVER.'&action=set_speed&speed='.$i.'&input='.$input,'');
			}
		if($nb_softkeys>0)
			{
			if($nb_softkeys==4)
				{
				$object->addSoftkey('1',Aastra_get_label('Select',$language),'SoftKey:Select');
				$object->addSoftkey('3',Aastra_get_label('Back',$language),$XML_SERVER.'&action=zoom');
				$object->addSoftkey('4',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				}
			else if($nb_softkeys==6)
				{
				$object->addSoftkey('1',Aastra_get_label('Select',$language),'SoftKey:Select');
				$object->addSoftkey('4',Aastra_get_label('Back',$language),$XML_SERVER.'&action=zoom');
				$object->addSoftkey('6',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				}
			else
				{
				$object->addSoftkey('9',Aastra_get_label('Back',$language),$XML_SERVER.'&action=zoom&input='.$inpur);
				$object->addSoftkey('10',Aastra_get_label('Exit',$language),'SoftKey:Exit');
				$object->setCancelAction($XML_SERVER.'&action=zoom&input='.$input);
				}
			}
		break;

	# Set speed dial
	case 'set_speed':
		# Retrieve session
		$array=Aastra_read_session('directory');
		$temp=unserialize(base64_decode($array['directory']));
		$directory=$temp[1];

		# Update global variable
		$XML_SERVER.='&lookup='.$lookup.'&lastn='.$lastn.'&firstn='.$firstn.'&index='.$index.'&page='.$page.'&company='.$company;

		# Get user context
		$conf_speed=Aastra_get_user_context($user,'speed');

		# Save the new speed dial
		if($array_user['display']=='firstlast') $name=$directory[$index]['first'].' '.$directory[$index]['last'];
		else $name=$directory[$index]['last'].' '.$directory[$index]['first'];
		$conf_speed[$speed]['name']=$name;
		if($directory[$index]['work']!='') $conf_speed[$speed]['work']=prepare_number($directory[$index]['work'],2,$array_conf['Dialplan']);
		if($directory[$index]['mobile']!='') $conf_speed[$speed]['mobile']=prepare_number($directory[$index]['mobile'],2,$array_conf['Dialplan']);
		if($directory[$index]['home']!='') $conf_speed[$speed]['home']=prepare_number($directory[$index]['home'],2,$array_conf['Dialplan']);
		$conf_speed[$speed]['other']='';
		Aastra_save_user_context($user,'speed',$conf_speed);
		
		# Display update
		$object=new AastraIPPhoneTextScreen();
		$object->setDestroyOnExit();
		if($is_toptitle_supported) $object->setTopTitle(Aastra_get_label('List Updated',$language));
		else $object->setTitle(Aastra_get_label('List Updated',$language));
		$object->setText(sprintf(Aastra_get_label('%s stored in speed dial list at position %d.',$language),$name,$speed+1));
		if($nb_softkeys>0)
			{
			$object->addSoftkey($nb_softkeys-1,Aastra_get_label('Back',$language),$XML_SERVER.'&action=zoom');
			$object->addSoftkey($nb_softkeys,Aastra_get_label('Exit',$language),'SoftKey:Exit');
			$object->setCancelAction($XML_SERVER.'&action=zoom&input='.$input);
			}
		break;

	# Default
	default:
		# Do nothing
		$object=new AastraIPPhoneExecute();
		$object->addEntry('');
		break;
	}

# Send XML answer
$object->output();
exit;
?>
