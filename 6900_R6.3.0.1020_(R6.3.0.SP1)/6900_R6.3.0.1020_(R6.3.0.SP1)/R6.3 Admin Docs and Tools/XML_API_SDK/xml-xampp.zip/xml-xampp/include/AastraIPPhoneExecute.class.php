<?php
########################################################################################################
# Aastra XML API Classes - AastraIPPhoneExecute
# Copyright Mitel Networks 2005-2015
#
# AastraIPPhoneExecute object.
#
# Public methods
#
# Inherited from AastraIPPhone
#     setBeep() to enable a notification beep with the object (optional)
#     setEncodingUTF8() to change encoding from default ISO-8859-1 to UTF-8 (optional)
#     generate() to return the generated XML for the object
#     output(flush) to display the object
#          @flush		boolean optional, output buffer to be flushed out or not.
#
# Specific to the object
#     setTriggerDestroyOnExit() to set the triggerDestroyOnExit tag to "yes" (optional)
#     addEntry(url,interruptCall,title) to add an action to be executed.
#          @url		string
#          @interruptCall	string, optional, "yes" or "no"	
#          @title string, optional, title to be used in Wav.Play screen
#
# Example
#     require_once('AastraIPPhoneExecute.class.php');
#     $execute = new AastraIPPhoneExecute();
#     $execute->addEntry('http://myserver.com/script.php?choice=2');
#     $execute->addEntry('Command: Reset');
#     $execute->output();
#
########################################################################################################

require_once('AastraIPPhone.class.php');
require_once('AastraIPPhoneExecuteEntry.class.php');

class AastraIPPhoneExecute extends AastraIPPhone {
	var $_defaultIndex='';
	var $_triggerDestroyOnExit='';

	function addEntry($url,$interruptCall=NULL,$title='')
	{
		$this->_entries[] = new AastraIPPhoneExecuteEntry($url,$interruptCall,$title);
	}

	function setTriggerDestroyOnExit() 
	{
		$this->_triggerDestroyOnExit='yes';
	}

	function render()
	{
		# Beginning of root tag
		$out = "<AastraIPPhoneExecute";

		# Beep
		if($this->_beep=='yes') $out .= " Beep=\"yes\"";

		# TriggerDestroyOnExit
		if($this->_triggerDestroyOnExit=='yes') $out .= " triggerDestroyOnExit=\"yes\"";

		# End of root tag
		$out .= ">\n";

		# Execute Items
		if (isset($this->_entries) && is_array($this->_entries)) 
			{
			foreach ($this->_entries as $entry) $out .= $entry->render();
			}

		# End tag
		$out .= "</AastraIPPhoneExecute>\n";

		# Return XML object
		return($out);
	}
}
?>